vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|17 Mar 2017 06:53:41 -0000
vti_extenderversion:SR|12.0.0.0
vti_cacheddtm:TX|08 Mar 2014 05:46:58 -0000
vti_filesize:IR|2830
vti_backlinkinfo:VX|
vti_modifiedby:SR|jk5\\jk
