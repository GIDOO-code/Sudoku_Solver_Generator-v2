vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|17 Mar 2017 06:53:41 -0000
vti_extenderversion:SR|12.0.0.0
vti_cacheddtm:TX|09 Mar 2014 02:23:18 -0000
vti_filesize:IR|1214
vti_backlinkinfo:VX|
vti_modifiedby:SR|jk5\\jk
